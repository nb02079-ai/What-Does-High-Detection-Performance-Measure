"""DMBD 2025 원본 → 실행 단위 집계 (dmbd_event_counts.csv)

LLNL이 배포한 원본(이벤트 기록 trees_0.json ~ trees_7.json, 라벨 truth_labels_train.json / truth_labels_test.json,
약 8GB)은 용량 때문에 제출물에 넣지 않았다. 작성자가 자신의 PC에서 이 스크립트로 원본을 집계해
03_원자료/dmbd_event_counts.csv를 만들었다(2026-09-19 무렵).

실행: python aggregate_dmbd.py <원본 폴더 경로>
확인: 이 스크립트가 만드는 열 20개 + 라벨 JSON의 열 3개(year, label, test)가 제출된 CSV의 열 23개와 정확히 같음을 확인했다.
     원본이 없어 이 환경에서 다시 실행해 값까지 대조하지는 못했다.
"""
import sys, os
import pandas as pd

root = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', '')
EVENTS = ['process_create', 'process_term', 'image_load', 'net_connect', 'file_create',
          'reg_create_key', 'reg_write', 'reg_delete_key', 'reg_delete_value', 'detonation']

rows = []
for i in range(8):
    df = pd.read_json(root + f'trees_{i}.json')
    g = df.groupby('experiment')
    cnt = df.pivot_table(index='experiment', columns='RuleName', values='timestamp', aggfunc='size').fillna(0)  # 이벤트 종류별 개수
    tmin, tmax = g['timestamp'].min(), g['timestamp'].max()
    det = df[df.RuleName == 'detonation'].groupby('experiment')['timestamp'].min()
    part = cnt.copy()
    part['n_events'] = g.size()
    part['t_first'], part['t_last'], part['t_detonate'] = tmin, tmax, det
    part['duration_s'] = (tmax - tmin).dt.total_seconds()
    part['dur_after_detonation_s'] = (tmax - det).dt.total_seconds()
    part['n_uniq_child'] = g['child_name'].nunique()
    part['n_uniq_parent'] = g['parent_name'].nunique()
    part['n_uniq_cguid'] = g['child_guid'].nunique()
    rows.append(part.reset_index())
    print(f'trees_{i}.json 완료: {len(part)} 실행')

summary = pd.concat(rows, ignore_index=True)
for e in EVENTS:
    if e not in summary.columns:
        summary[e] = 0
summary[EVENTS] = summary[EVENTS].fillna(0).astype(int)

tr = pd.read_json(root + 'truth_labels_train.json'); tr['test'] = False
te = pd.read_json(root + 'truth_labels_test.json');  te['test'] = True
out = summary.merge(pd.concat([tr, te], ignore_index=True), on='experiment', how='left')
out.to_csv('dmbd_event_counts.csv', index=False)
print('최종:', out.shape)
