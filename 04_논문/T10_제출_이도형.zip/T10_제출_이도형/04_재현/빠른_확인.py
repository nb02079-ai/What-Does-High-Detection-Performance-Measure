"""빠른 확인 — 원자료에서 논문의 핵심 수치 두 개를 다시 계산한다 (1분 이내).

실행: 04_재현 폴더에서  python 빠른_확인.py
필요: pandas, numpy, scikit-learn  (requirements.txt)
"""
import os, time
import numpy as np, pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import StratifiedGroupKFold, cross_val_score
from sklearn.metrics import roc_auc_score

H = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(H, '..', '03_원자료')
t0 = time.time()

# [1] CIC-MalMem-2022: 실행 중인 서비스 수 하나로 갈리는가 (논문 4.1.1, 표 5)
c = pd.read_csv(os.path.join(DATA, 'MalMem2022.csv'))
X = c.select_dtypes('number').values
y = (c['Class'] == 'Malware').astype(int).values
run = c['Filename'].str.rsplit('-', n=1).str[0]                     # 악성: 같은 실행의 덤프를 한 묶음으로
groups = np.where(y == 1, run, 'B' + pd.Series(range(len(c))).astype(str))   # 정상: 실행 식별자가 없어 행 단위
cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)
acc = cross_val_score(DecisionTreeClassifier(max_depth=1, random_state=42), X, y, cv=cv, groups=groups).mean()
stump = DecisionTreeClassifier(max_depth=1, random_state=42).fit(X, y)
feat = c.select_dtypes('number').columns[stump.tree_.feature[0]]
print(f'[1] CIC-MalMem-2022  깊이 1 결정트리 정확도 = {acc*100:.2f}%   (논문: 99.65%)  — 분기 특징: {feat}')

# [2] DMBD 2025: 수집 연도만으로 라벨을 얼마나 맞히는가 (논문 4.1.2)
d = pd.read_csv(os.path.join(DATA, 'dmbd_event_counts.csv'), usecols=['year', 'label']).dropna(subset=['year'])
auc = roc_auc_score((d['label'] == 'malicious').astype(int), d['year'])
auc = max(auc, 1 - auc)                                               # 방향 보정
print(f'[2] DMBD 2025        수집 연도만으로 라벨 예측 ROC-AUC = {auc:.4f}   (논문: 0.907)  — 실행 {len(d):,}개')

print(f'소요 {time.time()-t0:.0f}초')
